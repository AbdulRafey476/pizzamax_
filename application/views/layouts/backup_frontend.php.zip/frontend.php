<!doctype html>
<html>
	<head>
	<?php 
	$CI =& get_instance();
	$CI->load->view('frontends/commons/header');
	?>
	</head>
	<body class="">
		
		<?php
		$CI->load->view('frontends/commons/modal');
		$CI->load->view('frontends/commons/topmenu');
		?>	
		<div class="content-wrapper">
			<?php echo $content; ?>
		</div>
		<?php
		$CI->load->view('frontends/commons/footer');
		?>
		<?php 
		if(isset($loadmap) && $loadmap === true) {
			$CI->load->view('frontends/commons/google');
		}
		if(isset($footerScripts) && !empty($footerScripts)) {
			echo $footerScripts;	
		}
		?>
	
	</body>
</html>